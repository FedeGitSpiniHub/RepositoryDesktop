package it.jac.javadb.lezione1b.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.sql.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.NativeQuery;

import it.jac.javadb.lezione1b.dao.PersonaDao;
import it.jac.javadb.lezione1b.entity.Malattia;
import it.jac.javadb.lezione1b.entity.Persona;
import it.jac.javadb.lezione1b.util.HibernateUtil;

public class PersonaDao extends BaseDao {
	
	private static final Logger log = LogManager.getLogger(PersonaDao.class);

	public void createPersona(Persona persona) throws ParseException {
		
		StringBuilder sql = new StringBuilder();
		
		sql.append("INSERT INTO PERSONA (ID, NOME, COGNOME, DATA_NASCITA, RECAPITO_TELEFONICO, INDIRIZZO_RESIDENZA, CREATION_TIME, CREATION_USER)");
		sql.append(" VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
		
		Connection connection = null;
		PreparedStatement pstm = null;
		
		try {
			connection = getConnection();
			
			pstm = connection.prepareStatement(sql.toString());
			
			pstm.setInt(1, persona.getId());
			pstm.setString(2, StringUtils.abbreviate(persona.getNome(), 45));
			pstm.setString(3, StringUtils.abbreviate(persona.getCognome(), 45));
			pstm.setDate(4, persona.getDataNascita());
			pstm.setString(5, StringUtils.abbreviate(persona.getRecapitoTelefonico(), 45));
			pstm.setString(6, StringUtils.abbreviate(persona.getIndirizzoResidenza(), 45));
			pstm.setTimestamp(7, new java.sql.Timestamp(persona.getCreationTime().getTime()));
			pstm.setString(8, persona.getCreationUser());
			
			pstm.execute();
			
		} catch(SQLException | ClassNotFoundException e) {
			
			e.printStackTrace();
			
		} finally {
			
			if (pstm != null) {
				try {
					pstm.close();
				} catch (SQLException e) {
					
				}
			}
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {
					
				}
			}
		}
	}
	
	public Persona findPersonById(int id) {

		try (Session session = HibernateUtil.getSessionFactory().openSession()) {

			return session.find(Persona.class, id);
		}
	}
	
	public void save(Persona persona) {

		log.debug("try to save person " + persona);
		
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {

			Transaction tx = session.beginTransaction();
			try {

				session.save(persona);
				tx.commit();
				log.debug("Person saved");
				
			} catch(Exception e) {
				log.error("Error saving person", e);
				tx.rollback();
			}
		}
	}
	
	public void updatePersona(Persona persona) {
		
		System.out.println("Stai modificando la persona " + persona.getId());
		
		StringBuilder sql = new StringBuilder();
		
		sql.append("UPDATE PERSONA");
		sql.append(" SET NOME = ?,");
		sql.append(" 	 COGNOME = ?,");
		sql.append(" 	 DATA_NASCITA = ?,");
		sql.append(" 	 RECAPITO_TELEFONICO = ?,");
		sql.append(" 	 INDIRIZZO_RESIDENZA = ?,");
		sql.append(" 	 UPDATE_TIME = ?,");
		sql.append(" 	 UPDATE_USER = ?");
		sql.append(" WHERE ID = ?");
				
		Connection connection = null;
		PreparedStatement pstm = null;
		
		try {
			connection = getConnection();
			
			pstm = connection.prepareStatement(sql.toString());
			
			
			pstm.setString(1, persona.getNome());
			pstm.setString(2, persona.getCognome());
			pstm.setDate(3, persona.getDataNascita());
			pstm.setString(4, persona.getRecapitoTelefonico());
			pstm.setString(5, persona.getIndirizzoResidenza());
			pstm.setTimestamp(6, new java.sql.Timestamp(persona.getUpdateTime().getTime()));
			pstm.setString(7, persona.getUpdateUser());
			pstm.setInt(8, persona.getId());
			
			pstm.execute();
			
		} catch(SQLException | ClassNotFoundException e) {
			
			e.printStackTrace();
			
		} finally {
			
			if (pstm != null) {
				try {
					pstm.close();
				} catch (SQLException e) {
					
				}
			}
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {
					
				}
			}
		}
	}
	
	public void deletePersona(int id) {
		
		StringBuilder sql = new StringBuilder();
		
		sql.append("DELETE FROM PERSONA");
		sql.append(" WHERE ID = ?");
				
		Connection connection = null;
		PreparedStatement pstm = null;
		
		try {
			connection = getConnection();
			
			pstm = connection.prepareStatement(sql.toString());
			
			pstm.setInt(1, id);
			
			pstm.execute();
			
		} catch(SQLException | ClassNotFoundException e) {
			
			e.printStackTrace();
			
		} finally {
			
			if (pstm != null) {
				try {
					pstm.close();
				} catch (SQLException e) {
					
				}
			}
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {
					
				}
			}
		}
	}
	
	public List<Persona> findAll() {

		log.debug("try to find all entities");
		
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			
			NativeQuery<Persona> query = session.createNativeQuery("select * from persona", Persona.class);
	
			List<Persona> list = query.list();
			
			log.debug("found [" + list.size() + "] entities");
			
			return list;
		}
	}
}
