package it.jac.javadb.lezione1b.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.NativeQuery;

import it.jac.javadb.lezione1b.entity.Malattia;
import it.jac.javadb.lezione1b.entity.Vaccino;
import it.jac.javadb.lezione1b.util.HibernateUtil;

public class VaccinoDao extends BaseDao {
	
	private static final Logger log = LogManager.getLogger(VaccinoDao.class);

	public void createVaccino(Vaccino vaccino) throws ParseException {
		
		StringBuilder sql = new StringBuilder();
		
		sql.append("INSERT INTO VACCINO (ID, LIVELLO_RISCHIO, ANNO, MALATTIE_PREVENUTE, CREATION_TIME, CREATION_USER)");
		sql.append(" VALUES (?, ?, ?, ?, ?, ?)");
		
		Connection connection = null;
		PreparedStatement pstm = null;
		
		try {
			connection = getConnection();
			
			pstm = connection.prepareStatement(sql.toString());
			
			pstm.setInt(1, vaccino.getId());
			pstm.setInt(2, vaccino.getLivelloRischio());
			pstm.setInt(3, vaccino.getAnno());
			pstm.setString(4, vaccino.getMalattiePrevenute());
			pstm.setTimestamp(5, new java.sql.Timestamp(vaccino.getCreationTime().getTime()));
			pstm.setString(6, vaccino.getCreationUser());
			
			pstm.execute();
			
		} catch(SQLException | ClassNotFoundException e) {
			
			e.printStackTrace();
			
		} finally {
			
			if (pstm != null) {
				try {
					pstm.close();
				} catch (SQLException e) {
					
				}
			}
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {
					
				}
			}
		}
	}
	
	public Vaccino findVaccineById(int id) {

		try (Session session = HibernateUtil.getSessionFactory().openSession()) {

			return session.find(Vaccino.class, id);
		}
	}
	
	public void save(Vaccino vaccino) {

		log.debug("try to save vaccine " + vaccino);
		
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {

			Transaction tx = session.beginTransaction();
			try {

				session.persist(vaccino);
				tx.commit();
				log.debug("Vaccine saved");
				
			} catch(Exception e) {
				log.error("Error saving vaccine", e);
				tx.rollback();
			}
		}
	}
	
	public void updateVaccino(Vaccino vaccine) {
		
		System.out.println("Stai modificando il vaccino n� " + vaccine.getId());
		
		StringBuilder sql = new StringBuilder();
		
		sql.append("UPDATE VACCINO");
		sql.append(" SET LIVELLO_RISCHIO = ?,");
		sql.append(" 	 ANNO = ?,");
		sql.append(" 	 MALATTIE_PREVENUTE = ?,");
		sql.append(" 	 UPDATE_TIME = ?,");
		sql.append(" 	 UPDATE_USER = ?");
		sql.append(" WHERE ID = ?");
				
		Connection connection = null;
		PreparedStatement pstm = null;
		
		try {
			connection = getConnection();
			
			pstm = connection.prepareStatement(sql.toString());
			
			
			pstm.setInt(1, vaccine.getLivelloRischio());
			pstm.setInt(2, vaccine.getAnno());
			pstm.setString(3, vaccine.getMalattiePrevenute());
			pstm.setTimestamp(4, new java.sql.Timestamp(vaccine.getUpdateTime().getTime()));
			pstm.setString(5, vaccine.getUpdateUser());
			pstm.setInt(6, vaccine.getId());
			
			pstm.execute();
			
		} catch(SQLException | ClassNotFoundException e) {
			
			e.printStackTrace();
			
		} finally {
			
			if (pstm != null) {
				try {
					pstm.close();
				} catch (SQLException e) {
					
				}
			}
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {
					
				}
			}
		}
	}
	
	public void deleteVaccine(int id) {
		
		StringBuilder sql = new StringBuilder();
		
		sql.append("DELETE FROM VACCINO");
		sql.append(" WHERE ID = ?");
				
		Connection connection = null;
		PreparedStatement pstm = null;
		
		try {
			connection = getConnection();
			
			pstm = connection.prepareStatement(sql.toString());
			
			pstm.setInt(1, id);
			
			pstm.execute();
			
		} catch(SQLException | ClassNotFoundException e) {
			
			e.printStackTrace();
			
		} finally {
			
			if (pstm != null) {
				try {
					pstm.close();
				} catch (SQLException e) {
					
				}
			}
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {
					
				}
			}
		}
	}
	
	public List<Vaccino> findAll() {

		log.debug("try to find all entities");
		
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			
			NativeQuery<Vaccino> query = session.createNativeQuery("select * from vaccino", Vaccino.class);
	
			List<Vaccino> list = query.list();
			
			log.debug("found [" + list.size() + "] entities");
			
			return list;
		}
	}
}
