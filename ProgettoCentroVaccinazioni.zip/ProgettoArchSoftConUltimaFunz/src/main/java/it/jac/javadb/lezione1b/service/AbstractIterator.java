package it.jac.javadb.lezione1b.service;

public interface AbstractIterator {
	
	public Object nextItem();

}
