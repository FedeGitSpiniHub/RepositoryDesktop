package it.jac.javadb.lezione1b.service;

public interface Component {
	
	public void add();
	public void remove();
	public void operation();

}
