package it.jac.javadb.lezione1b.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import it.jac.javadb.lezione1b.entity.Persona;

public class ConcreteAggregator implements Aggregator {
	
	public Iterator createIterator() {
		
		Iterator<Persona> persone = Persona.iterator();
		
		return persone;
	}
}
