package it.jac.javadb.lezione1b.service;

import java.text.ParseException;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import it.jac.javadb.lezione1b.dao.PersonaDao;
import it.jac.javadb.lezione1b.entity.Persona;
import it.jac.javadb.lezione1b.entity.Vaccino;
import it.jac.javadb.lezione1b.util.Utils;

public class PersonaService implements Iterator<Persona> {

	private static PersonaDao dao = new PersonaDao();

	public void testConnessione() {
		
		System.out.println("Test connessione");
		
		boolean test = dao.testConnessione();
		if (test) {
		
			System.out.println("Test OK");
		}
	}
	
	public void addPerson(List<Persona> persone) throws ParseException {
		Scanner scanner = new Scanner(System.in);
		PersonaService ps = new PersonaService();
		Persona persona = ps.creaPersona(scanner);
		persone.add(persona);
	}
	
	public void stampaLista() {

		System.out.println("Stampa lista");

		List<Persona> list = dao.findAll();
		Utils u = new Utils();
		u.stampaListaPersone(list);
	}
	
	public Persona creaPersona(Scanner s) throws ParseException {
		
		String nome, cognome, dataNascita, recapitoTelefonico, indirizzoResidenza;
		
		System.out.println("Crea persona");

		System.out.println("Inserisci il nome:");
		nome = s.nextLine();
		
		System.out.println("Inserisci il cognome:");
		cognome = s.nextLine();
		
		System.out.println("Inserisci la data di nascita:");
		dataNascita = s.nextLine();
		
		System.out.println("Inserisci il recapito telefonico:");
		recapitoTelefonico = s.nextLine();
		
		System.out.println("Inserisci l'indirizzo di residenza:");
		indirizzoResidenza = s.nextLine();
		
		Persona persona = new Persona();
		persona.setNome(nome);
		persona.setCognome(cognome);
		persona.setDataNascita(dataNascita);
		persona.setRecapitoTelefonico(recapitoTelefonico);
		persona.setIndirizzoResidenza(indirizzoResidenza);
		persona.setId(6);
		persona.setCreationTime(new Date());
		persona.setCreationUser("admin");
		
		dao.createPersona(persona);
		
		return persona;	
	}
	
	public Persona modificaPersona(Scanner s, int id) throws ParseException
	{	
		String nome, cognome, dataNascita, recapitoTelefonico, indirizzoResidenza;
		
		System.out.println("Modifica persona n� " + id);
		
		System.out.println("Inserisci nome: ");
		nome = s.next();
		
		System.out.println("Inserisci il cognome:");
		cognome = s.next();
		
		System.out.println("Inserisci la data di nascita:");
		dataNascita = s.next();
		
		System.out.println("Inserisci il recapito telefonico:");
		recapitoTelefonico = s.next();
		
		s.nextLine();
		
		System.out.println("Inserisci l'indirizzo di residenza:");
		indirizzoResidenza = s.nextLine();
		
		Persona persona = new Persona();
		persona.setNome(nome);
		persona.setCognome(cognome);
		persona.setDataNascita(dataNascita);
		persona.setRecapitoTelefonico(recapitoTelefonico);
		persona.setIndirizzoResidenza(indirizzoResidenza);
		persona.setId(id);
		persona.setUpdateTime(new Date());
		persona.setUpdateUser("admin");
	
		dao.updatePersona(persona);
		
		return persona;
	}
	
	public void removePerson(int idPersona, List<Persona> persone) {
		Scanner scanner = new Scanner(System.in);
		PersonaService ps = new PersonaService();
		ps.eliminaPersona(idPersona);
		Persona p = ps.findPersonById(idPersona);
	
		for(Persona persona: persone)
		{
			if(persona.equals(p))
			{
				persone.remove(persona);
			}
		}
	}
	
	public void savePerson(Persona persona) {
		
		persona.setCreationUser("system");
		persona.setCreationTime(new Date());
		
		dao.save(persona);
	}
	
	public void eliminaPersona(int idPersona) {

		System.out.println("Elimina persona n� " + idPersona);

		dao.deletePersona(idPersona);
	}
	
	public Persona findPersonById(int id) {
		return dao.findPersonById(id);
	}
	
	public void stampaPersona(int idPersona) {

		System.out.println("Stampa persona ");

		Persona persona = dao.findPersonById(idPersona);
		
		Utils u = new Utils();
		
		u.stampaListaPersone(Arrays.asList(persona));
	}
	
	@Override
	public boolean hasNext() {
		return false;
	}

	@Override
	public Persona next() {
		return null;
	}
}
