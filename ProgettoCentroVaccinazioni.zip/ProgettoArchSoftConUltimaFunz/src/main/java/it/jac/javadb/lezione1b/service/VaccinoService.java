package it.jac.javadb.lezione1b.service;

import java.text.ParseException;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import it.jac.javadb.lezione1b.dao.MalattiaDao;
import it.jac.javadb.lezione1b.dao.PrevenzioneDao;
import it.jac.javadb.lezione1b.dao.SomministrazioneDao;
import it.jac.javadb.lezione1b.dao.VaccinazioneDao;
import it.jac.javadb.lezione1b.dao.VaccinoDao;
import it.jac.javadb.lezione1b.entity.Malattia;
import it.jac.javadb.lezione1b.entity.Prevenzione;
import it.jac.javadb.lezione1b.entity.Somministrazione;
import it.jac.javadb.lezione1b.entity.Vaccinazione;
import it.jac.javadb.lezione1b.entity.Vaccino;
import it.jac.javadb.lezione1b.util.Utils;

public class VaccinoService {
	
	private static VaccinoDao dao = new VaccinoDao();
	
	public void addVaccine(List<Vaccino> vaccini) throws ParseException {
		Scanner scanner = new Scanner(System.in);
		VaccinoService vs = new VaccinoService();
		Vaccino vaccino = vs.creaVaccino(scanner);
		vaccini.add(vaccino);
	}
	
	public Vaccino creaVaccino(Scanner s) throws ParseException {
		
		int livelloRischio, anno;
		String malattiePrevenute;
		
		System.out.println("Crea vaccino");
		
		System.out.println("Inserisci le malattie prevenute:");
		malattiePrevenute = s.nextLine();
	
		System.out.println("Inserisci il livello di rischio:");
		livelloRischio = s.nextInt();
		
		System.out.println("Inserisci l'anno:");
		anno = s.nextInt();
		
		Vaccino vaccino = new Vaccino();
		vaccino.setLivelloRischio(livelloRischio);
		vaccino.setAnno(anno);
		vaccino.setMalattiePrevenute(malattiePrevenute);
		vaccino.setId(5);
		vaccino.setCreationTime(new Date());
		vaccino.setCreationUser("admin");
		
		dao.createVaccino(vaccino);
		
		return vaccino;
	}
	
	public Vaccino modificaVaccino(Scanner s, int id) throws ParseException
	{
		int livelloRischio, anno;
		String malattiePrevenute;
	
		System.out.println("Inserisci il livello di rischio:");
		livelloRischio = s.nextInt();
		
		System.out.println("Inserisci l'anno:");
		anno = s.nextInt();
		s.nextLine();
		
		System.out.println("Inserisci le malattie prevenute:");
		malattiePrevenute = s.nextLine();
		
		Vaccino vaccino = new Vaccino();
		vaccino.setLivelloRischio(livelloRischio);
		vaccino.setAnno(anno);
		vaccino.setMalattiePrevenute(malattiePrevenute);
		vaccino.setId(id);
		vaccino.setUpdateTime(new Date());
		vaccino.setUpdateUser("admin");
	
		dao.updateVaccino(vaccino);
		
		return vaccino;
	}
	
	public void eliminaVaccino(int idVaccino) {

		System.out.println("Elimina vaccino n� " + idVaccino);

		dao.deleteVaccine(idVaccino);
	}
	
	public void removeVaccine(int idVaccino, List<Vaccino> vaccini) {
		Scanner scanner = new Scanner(System.in);
		VaccinoService vs = new VaccinoService();
		vs.eliminaVaccino(idVaccino);
		Vaccino v = vs.findVaccineById(idVaccino);
	
		for(Vaccino vaccino: vaccini)
		{
			if(vaccino.equals(v))
			{
				vaccini.remove(vaccino);
			}
		}
	}
	
	public void getMalattiePrevenute()
	{
		MalattiaDao md = new MalattiaDao();
		PrevenzioneDao pd = new PrevenzioneDao();
		
		List<Malattia> malattie = md.findAll();
		
		List<Prevenzione> vaccini = pd.findAll();
		
		MalattiaService ms = new MalattiaService();
		
		for(int i = 0; i < malattie.size(); i++)
		{
			for(int j = 0; j < vaccini.size(); j++)
			{
				if(malattie.get(i).getId() == vaccini.get(j).getIdmalattia())
				{
					Malattia m = ms.findDiseaseById(vaccini.get(j).getIdmalattia());
					System.out.println("Il vaccino n� " + vaccini.get(j).getIdvaccino() + " previene le seguenti malattie: " + m.getNome());
				}
			}
		}
	}
	
	public void getVaccinazioniEffettuate()
	{
		VaccinazioneDao vd = new VaccinazioneDao();
		SomministrazioneDao sd = new SomministrazioneDao();
		VaccinoDao vcd = new VaccinoDao();
		
		List<Somministrazione> somministrazioni = sd.findAll(); 
		
		List<Vaccinazione> vaccinazioni = vd.findAll();
		
		List<Vaccino> vaccini = vcd.findAll();
		
		for(int i = 0; i < vaccini.size(); i++)
		{
			for(int j = 0; j < somministrazioni.size(); j++)
			{
				if(vaccini.get(i).getId() == somministrazioni.get(j).getIdvaccino())
				{
					Vaccinazione v = new Vaccinazione();
					System.out.println("Il vaccino n� " + vaccini.get(i).getId() + (" : ") + " � stato oggetto delle seguenti vaccinazioni: " + somministrazioni.get(j).getIdvaccinazione());
				}
			}
		}
		
	}
	
	public Vaccino findVaccineById(int id) {
		return dao.findVaccineById(id);
	}
	
	public void stampaVaccino(int idVaccino) {

		System.out.println("Stampa vaccino ");

		Vaccino vaccino = dao.findVaccineById(idVaccino);
		
		Utils u = new Utils();
		
		u.stampaListaVaccini(Arrays.asList(vaccino));
	}
}
