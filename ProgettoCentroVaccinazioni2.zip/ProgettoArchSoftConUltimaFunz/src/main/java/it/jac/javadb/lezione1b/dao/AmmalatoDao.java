package it.jac.javadb.lezione1b.dao;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.query.NativeQuery;

import it.jac.javadb.lezione1b.entity.Ammalato;
import it.jac.javadb.lezione1b.entity.Malattia;
import it.jac.javadb.lezione1b.entity.Persona;
import it.jac.javadb.lezione1b.entity.Vaccino;
import it.jac.javadb.lezione1b.service.MalattiaService;
import it.jac.javadb.lezione1b.util.HibernateUtil;

public class AmmalatoDao {
	
	private static final Logger log = LogManager.getLogger(AmmalatoDao.class);
	
	private static final PersonaDao pd = new PersonaDao();
	
	private static final MalattiaDao md = new MalattiaDao();
	
	private static final VaccinoDao vd = new VaccinoDao();
	
	public List<Ammalato> findAll() {

		log.debug("try to find all entities");
		
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			
			NativeQuery<Ammalato> query = session.createNativeQuery("select * from ammalato", Ammalato.class);
	
			List<Ammalato> list = query.list();
			
			log.debug("found [" + list.size() + "] entities");
			
			return list;
		}
	}
	
	public void getMediaPersoneAmmalate()
	{
		List<Persona> persone = pd.findAll();
		AmmalatoDao ad = new AmmalatoDao();
		List<Ammalato> ammalati = ad.findAll();
		List<Malattia> malattie = md.findAll();
		List<Vaccino> vaccini = vd.findAll();
		double percentualeAmmalati = 0;
		double numPersone = persone.size();
		
			for(int j = 0; j < vaccini.size(); j++)
			{
				for(int z = 0; z < ammalati.size(); z++)
				{
					double numAmmalati = 0;
					
						if((z + 1) <= ammalati.size())
						{	   
							if(md.findDiseaseById(ammalati.get(z).getIdmalattia()).getNome().equalsIgnoreCase(vaccini.get(j).getMalattiePrevenute()))
							{
								numAmmalati = numAmmalati + 1;
							}
						}	
						
						System.out.println("Numero ammalati di malattie prevenibili dal vaccino " + vaccini.get(j).getId() + " : " + numAmmalati);
						percentualeAmmalati = numAmmalati / numPersone;
						System.out.println("percentuale: " + percentualeAmmalati);
				}
			}
	}
}