package it.jac.javadb.lezione1b.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.HashSet;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.mapping.Set;
import org.hibernate.query.NativeQuery;

import it.jac.javadb.lezione1b.entity.Malattia;
import it.jac.javadb.lezione1b.util.HibernateUtil;

public class MalattiaDao extends BaseDao {
	
	private static final Logger log = LogManager.getLogger(MalattiaDao.class);
	
	public void createMalattia(Malattia malattia) throws ParseException {
		
		StringBuilder sql = new StringBuilder();
		
		sql.append("INSERT INTO MALATTIA (ID, NOME, TIPO, CREATION_TIME, CREATION_USER)");
		sql.append(" VALUES (?, ?, ?, ?, ?)");
		
		Connection connection = null;
		PreparedStatement pstm = null;
		
		try {
			connection = getConnection();
			
			pstm = connection.prepareStatement(sql.toString());
			
			pstm.setInt(1, malattia.getId());
			pstm.setString(2, StringUtils.abbreviate(malattia.getNome(), 20));
			pstm.setString(3, StringUtils.abbreviate(malattia.getTipo(), 45));
			pstm.setTimestamp(4, new java.sql.Timestamp(malattia.getCreationTime().getTime()));
			pstm.setString(5, malattia.getCreationUser());
			
			pstm.execute();
			
		} catch(SQLException | ClassNotFoundException e) {
			
			e.printStackTrace();
			
		} finally {
			
			if (pstm != null) {
				try {
					pstm.close();
				} catch (SQLException e) {
					
				}
			}
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {
					
				}
			}
		}
	}
	
	public Malattia findDiseaseById(int id) {

		try (Session session = HibernateUtil.getSessionFactory().openSession()) {

			return session.find(Malattia.class, id);
		}
	}
	
	public void save(Malattia malattia) {

		log.debug("try to save disease " + malattia);
		
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {

			Transaction tx = session.beginTransaction();
			try {

				session.persist(malattia);
				tx.commit();
				log.debug("Disease saved");
				
			} catch(Exception e) {
				log.error("Error saving disease", e);
				tx.rollback();
			}
		}
	}
	
	public void updateMalattia(Malattia malattia) {
		
		System.out.println("Stai modificando la malattia n� " + malattia.getId());
		
		StringBuilder sql = new StringBuilder();
		
		sql.append("UPDATE MALATTIA");
		sql.append(" SET TIPO = ?,");
		sql.append("     NOME = ?,");
		sql.append(" 	 UPDATE_TIME = ?,");
		sql.append(" 	 UPDATE_USER = ?");
		sql.append(" WHERE ID = ?");
				
		Connection connection = null;
		PreparedStatement pstm = null;
		
		try {
			connection = getConnection();
			
			pstm = connection.prepareStatement(sql.toString());
			
			
			pstm.setString(1, malattia.getTipo());
			pstm.setString(2, malattia.getNome());
			pstm.setTimestamp(3, new java.sql.Timestamp(malattia.getUpdateTime().getTime()));
			pstm.setString(4, malattia.getUpdateUser());
			pstm.setInt(5, malattia.getId());
			
			
			pstm.execute();
			
		} catch(SQLException | ClassNotFoundException e) {
			
			e.printStackTrace();
			
		} finally {
			
			if (pstm != null) {
				try {
					pstm.close();
				} catch (SQLException e) {
					
				}
			}
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {
					
				}
			}
		}
	}
	
	public void deleteMalattia(int id) {
		
		StringBuilder sql = new StringBuilder();
		
		sql.append("DELETE FROM MALATTIA");
		sql.append(" WHERE ID = ?");
				
		Connection connection = null;
		PreparedStatement pstm = null;
		
		try {
			connection = getConnection();
			
			pstm = connection.prepareStatement(sql.toString());
			
			pstm.setInt(1, id);
			
			pstm.execute();
			
		} catch(SQLException | ClassNotFoundException e) {
			
			e.printStackTrace();
			
		} finally {
			
			if (pstm != null) {
				try {
					pstm.close();
				} catch (SQLException e) {
					
				}
			}
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {
					
				}
			}
		}
	}
	
	public List<Malattia> findAll() {

		log.debug("try to find all entities");
		
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			
			NativeQuery<Malattia> query = session.createNativeQuery("select * from malattia", Malattia.class);
	
			List<Malattia> list = query.list();
			
			log.debug("found [" + list.size() + "] entities");
			
			return list;
		}
	}
}
