package it.jac.javadb.lezione1b.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import it.jac.javadb.lezione1b.dao.PersonaDao;
import it.jac.javadb.lezione1b.dao.VaccinatoDao;
import it.jac.javadb.lezione1b.dao.VaccinazioneDao;

@Entity
@Table(name = "vaccinato")
public class Vaccinato implements Serializable {
	
	private static final PersonaDao pd = new PersonaDao();
	
	private static final VaccinazioneDao vd = new VaccinazioneDao();
	
	private static final VaccinatoDao vcd = new VaccinatoDao();
	
	@Id
	@Column(name = "idpersona")
	private int idPersona;
	
	@Id
	@Column(name = "idvaccinazione")
	private int idVaccinazione;
	
	@Column(name = "creation_user", length = 20)
	private String creationUser;
	
	@Column(name = "update_user", length = 20)
	private String updateUser;
	
	@Column(name = "creation_time")
	private Date creationTime;
	
	@Column(name = "update_time")
	private Date updateTime;

	public int getIdPersona() {
		return idPersona;
	}

	public void setIdPersona(int idPersona) {
		this.idPersona = idPersona;
	}

	public int getIdvaccinazione() {
		return idVaccinazione;
	}

	public void setIdVaccinazione(int idVaccinazione) {
		this.idVaccinazione = idVaccinazione;
	}

	public String getCreationUser() {
		return creationUser;
	}

	public void setCreationUser(String creationUser) {
		this.creationUser = creationUser;
	}

	public String getUpdateUser() {
		return updateUser;
	}

	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}

	public Date getCreationTime() {
		return creationTime;
	}

	public void setCreationTime(Date creationTime) {
		this.creationTime = creationTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	
	@Override
	public String toString() {
		return "id persona: " + idPersona + ", id vaccinazione: " + idVaccinazione + ", creation time: " + creationTime + ", creation user: "
				+  ", update time: " + updateTime + ", update user: " + updateUser + ""; 
	}
}
