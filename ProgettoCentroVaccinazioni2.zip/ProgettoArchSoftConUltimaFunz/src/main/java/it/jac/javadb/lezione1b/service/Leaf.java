package it.jac.javadb.lezione1b.service;

public class Leaf implements Component {

	@Override
	public void add() {

	}

	@Override
	public void remove() {

	}

	@Override
	public void operation() {

	}
}
