package it.jac.javadb.lezione1b.service;

import it.jac.javadb.lezione1b.entity.Persona;

public class Node {
	
	private Persona data;
    private Node next;

    private Node(Persona data) {
        this.data = data;
        next = null;
    }
    
    public Persona getData()
    {
    	return data;
    }
    
    public void setData(Persona data)
    {
    	this.data = data;
    }
    
    public Node getNext()
    {
    	return next;
    }
    
    public void setNext(Node next)
    {
    	this.next = next;
    }
}
