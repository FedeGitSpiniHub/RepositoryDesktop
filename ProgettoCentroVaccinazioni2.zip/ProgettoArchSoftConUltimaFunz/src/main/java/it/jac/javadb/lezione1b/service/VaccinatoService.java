package it.jac.javadb.lezione1b.service;

import java.util.List;

import it.jac.javadb.lezione1b.dao.PersonaDao;
import it.jac.javadb.lezione1b.dao.VaccinatoDao;
import it.jac.javadb.lezione1b.dao.VaccinazioneDao;
import it.jac.javadb.lezione1b.entity.Persona;
import it.jac.javadb.lezione1b.entity.Vaccinato;
import it.jac.javadb.lezione1b.entity.Vaccinazione;

public class VaccinatoService {
	
	private static final PersonaDao pd = new PersonaDao();
	private static final VaccinazioneDao vd = new VaccinazioneDao();
	private static final VaccinatoDao vcd = new VaccinatoDao();
	
	public void getVaccinazioni()
	{
		List<Persona> persone = pd.findAll();
		List<Vaccinazione> vaccinazioni = vd.findAll();
		List<Vaccinato> vaccinati = vcd.findAll();
		
		for(int i = 0; i < persone.size(); i++)
		{
			for(int z = 0; z < vaccinati.size(); z++)
			{
				if(persone.get(i).getId() == vaccinati.get(z).getIdPersona())
				{
					System.out.println("La persona n� " + persone.get(i).getId() + " ha effettuato le seguenti vaccinazioni: " + vaccinati.get(z).getIdvaccinazione());
				}
			}
		}
	}
}
