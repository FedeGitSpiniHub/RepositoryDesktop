package it.jac.javadb.lezione1b.service;

import java.text.ParseException;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import it.jac.javadb.lezione1b.dao.VaccinazioneDao;
import it.jac.javadb.lezione1b.entity.Malattia;
import it.jac.javadb.lezione1b.entity.Vaccinazione;
import it.jac.javadb.lezione1b.util.Utils;

public class VaccinazioneService implements Component {
	
private static VaccinazioneDao dao = new VaccinazioneDao();

	public Vaccinazione creaVaccinazione(Scanner s) throws ParseException {
		
		String data;
		
		System.out.println("Crea vaccinazione");
	
		System.out.println("Inserisci la data:");
		data = s.nextLine();
		
		Vaccinazione vaccinazione = new Vaccinazione();
		vaccinazione.setData(data);
		vaccinazione.setId(5);
		vaccinazione.setCreationTime(new Date());
		vaccinazione.setCreationUser("admin");
		
		dao.createVaccinazione(vaccinazione);
		
		return vaccinazione;
	}

	public void eliminaVaccinazione(int idVaccinazione) {

		System.out.println("Elimina vaccinazione n� " + idVaccinazione);

		dao.deleteVaccination(idVaccinazione);
	}
	
	public void removeVaccination(int idVaccinazione, List<Vaccinazione> vaccinazioni) {
		Scanner scanner = new Scanner(System.in);
		VaccinazioneService vs = new VaccinazioneService();
		vs.eliminaVaccinazione(idVaccinazione);
		Vaccinazione v = vs.findVaccinationById(idVaccinazione);
	
		for(Vaccinazione vaccinazione: vaccinazioni)
		{
			if(vaccinazione.equals(v))
			{
				vaccinazioni.remove(vaccinazione);
			}
		}
	}
	
	public Vaccinazione findVaccinationById(int id) {
		return dao.findVaccinationById(id);
	}
	
	public Vaccinazione modificaVaccinazione(Scanner s, int id) throws ParseException
	{
		String data;
		
		System.out.println("Modifica vaccinazione n� " + id);
		
		System.out.println("Inserisci data: ");
		data = s.next();
		
		Vaccinazione vaccinazione = new Vaccinazione();
		vaccinazione.setData(data);
		vaccinazione.setId(id);
		vaccinazione.setUpdateTime(new Date());
		vaccinazione.setUpdateUser("admin");
	
		dao.updateVaccinazione(vaccinazione);
		
		return vaccinazione;
	}
	
	public void stampaVaccinazione(int idVaccinazione) {

		System.out.println("Stampa vaccinazione ");

		Vaccinazione vaccinazione = dao.findVaccinationById(idVaccinazione);
		
		Utils u = new Utils();
		
		u.stampaListaVaccinazioni(Arrays.asList(vaccinazione));
	}
	
	public void addVaccination(List<Vaccinazione> vaccinazioni) throws ParseException {
		Scanner scanner = new Scanner(System.in);
		VaccinazioneService vs = new VaccinazioneService();
		Vaccinazione vaccinazione = vs.creaVaccinazione(scanner);
		vaccinazioni.add(vaccinazione);
	}

	@Override
	public void add() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void remove() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void operation() {
		// TODO Auto-generated method stub
		
	}
}
