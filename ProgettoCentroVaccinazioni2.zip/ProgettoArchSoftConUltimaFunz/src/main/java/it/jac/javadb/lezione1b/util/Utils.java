package it.jac.javadb.lezione1b.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import it.jac.javadb.lezione1b.dao.MalattiaDao;
import it.jac.javadb.lezione1b.dao.PersonaDao;
import it.jac.javadb.lezione1b.dao.VaccinazioneDao;
import it.jac.javadb.lezione1b.dao.VaccinoDao;
import it.jac.javadb.lezione1b.entity.Malattia;
import it.jac.javadb.lezione1b.entity.Persona;
import it.jac.javadb.lezione1b.entity.Vaccinazione;
import it.jac.javadb.lezione1b.entity.Vaccino;

public class Utils implements Iterator<Persona> {

	public static int position = -1;
	public static List<Persona> persone = new ArrayList<Persona>();
	
	public void stampaListaPersone(List<Persona> list)
	{
		PersonaDao dao = new PersonaDao();
		list = dao.findAll();
		System.out.println(list.get(0));
		for(int i = 0; i < list.size() - 1; i++)
		{
			System.out.println(next());
		}
	}
	
	public void stampaListaMalattie(List<Malattia> list)
	{
		MalattiaDao dao = new MalattiaDao();
		list = dao.findAll();
		System.out.println(list.get(0));
		for(int i = 0; i < list.size() - 1; i++)
		{
			System.out.println(next());
		}
	}
	
	public void stampaListaVaccini(List<Vaccino> list)
	{
		VaccinoDao dao = new VaccinoDao();
		list = dao.findAll();
		System.out.println(list.get(0));
		for(int i = 0; i < list.size() - 1; i++)
		{
			System.out.println(next());
		}
	}
	
	public void stampaListaVaccinazioni(List<Vaccinazione> list)
	{
		VaccinazioneDao dao = new VaccinazioneDao();
		list = dao.findAll();
		System.out.println(list.get(0));
		for(int i = 0; i < list.size() - 1; i++)
		{
			System.out.println(next());
		}
	}
	
	@Override
	public boolean hasNext() {
		return next() != null;
	}
	
	@Override
	public Persona next() {
		position++;
        return position < persone.size() ? persone.get(position) : null;
	}
	
	@Override
	public void remove() 
	{
		Iterator.super.remove();
		persone.remove(persone.get(position));
	}
}
