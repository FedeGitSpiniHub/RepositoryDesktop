package it.jac.javadb.lezione1b;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import it.jac.javadb.lezione1b.dao.AmmalatoDao;
import it.jac.javadb.lezione1b.dao.MalattiaDao;
import it.jac.javadb.lezione1b.dao.PersonaDao;
import it.jac.javadb.lezione1b.dao.VaccinazioneDao;
import it.jac.javadb.lezione1b.dao.VaccinoDao;
import it.jac.javadb.lezione1b.entity.Malattia;
import it.jac.javadb.lezione1b.entity.Persona;
import it.jac.javadb.lezione1b.entity.Vaccinazione;
import it.jac.javadb.lezione1b.entity.Vaccino;
import it.jac.javadb.lezione1b.service.Component;
import it.jac.javadb.lezione1b.service.ConcreteIterator;
import it.jac.javadb.lezione1b.service.MalattiaService;
import it.jac.javadb.lezione1b.service.PersonaService;
import it.jac.javadb.lezione1b.service.VaccinatoService;
import it.jac.javadb.lezione1b.service.VaccinazioneService;
import it.jac.javadb.lezione1b.service.VaccinoService;
import it.jac.javadb.lezione1b.util.Utils;

public class MainApp2 implements Iterator, Component {

	public static MainApp2 mn = new MainApp2();

	public static final int ESCI = 0;

	public static final int STAMPALISTA = 1;

	public static final int AGGIUNGI = 2;

	public static final int MODIFICA = 3;

	public static final int ELIMINA = 4;

	public static final int CERCA = 5;
	public static String s;
	
	public static int position = -1;

	public static PersonaDao pd = new PersonaDao();

	public static PersonaService ps = new PersonaService();

	public static List<Persona> persone = new ArrayList<Persona>(10);
	public static List<Malattia> malattie = new ArrayList<Malattia>(10);
	public static List<Vaccino> vaccini = new ArrayList<Vaccino>(10);
	public static List<Vaccinazione> vaccinazioni = new ArrayList<Vaccinazione>(10);
	static final private Scanner in = new Scanner(System.in);
	
	public static boolean hasNext(List<?> list) {
		return position < list.size();  
	}

	public static void main(String[] args) throws ParseException, InputMismatchException {
		System.out.println("App Started");
		Scanner scanner = new Scanner(System.in);
		PersonaService ps = new PersonaService();

		MainApp2 mn = new MainApp2();
		mn.operation();
		VaccinatoService vs = new VaccinatoService();
		vs.getVaccinazioni();
		scanner.nextLine();
		AmmalatoDao dao = new AmmalatoDao();
		dao.getMediaPersoneAmmalate();
		scanner.nextLine();
		VaccinoService vcs = new VaccinoService();
		vcs.getMalattiePrevenute();
		scanner.nextLine();
		vcs.getVaccinazioniEffettuate();
		scanner.nextLine();
		MalattiaService ms = new MalattiaService();
		ms.getPersoneAmmalate();
		
	}

	public void remove() {

	}

	private static int getChoice() {
		printMenu();
		return in.nextInt();
	}

	@Override
	public void operation() throws ParseException {

		System.out.println("Inserisci la categoria di dati che vuoi gestire: ");
		String s = in.nextLine();
		Scanner in = new Scanner(System.in);
		int scelta = 0;
		Utils u = new Utils();

		if (s.equals("persone")) {

			do {
				scelta = getChoice();

				PersonaService ps = new PersonaService();
				PersonaDao dao = new PersonaDao();

				switch (scelta) {
				case STAMPALISTA: {
					persone = dao.findAll();

					for (int i = -1; i < persone.size() - 1; i++) {
						if (hasNext(persone)) {
							MainApp2 mn = new MainApp2();
							System.out.println(mn.next(persone));
						} else {
							System.out.println("Lista terminata");
						}
					}

					break;
				}

				case AGGIUNGI: {
					ps.add(persone);
					break;
				}

				case MODIFICA: {
					persone = pd.findAll();
					System.out.println("Inserisci l'id della persona da modificare: ");
					int id = in.nextInt();
					Persona p = ps.modificaPersona(in, id);
					persone.set(id - 1, p);
					break;
				}

				case ELIMINA: {
					System.out.println("Inserisci l'id della persona da eliminare: ");
					int id = in.nextInt();
					ps.remove(id, persone);
					break;
				}

				case CERCA: {
					System.out.println("Inserisci l'id della persona da cercare: ");
					int id = in.nextInt();
					Persona p = ps.findPersonById(id);
					System.out.println(p);
					break;
				}

				default: {
					System.out.println("Scelta non valida ");
					break;
				}
				}
			}

			while (scelta != ESCI);
		}

		else {
			if (s.equals("malattie")) {
				do {
					scelta = getChoice();

					MalattiaService ms = new MalattiaService();
					MalattiaDao md = new MalattiaDao();

					switch (scelta) {
					case STAMPALISTA: {
						malattie = md.findAll();

						for (int i = -1; i < malattie.size() - 1; i++) {
							if (hasNext(malattie)) {
								MainApp2 mn = new MainApp2();
								System.out.println(mn.next(malattie));
							} else {
								System.out.println("Lista terminata");
							}
						}

						break;
					}

					case AGGIUNGI: {
						ms.add(malattie);
						break;
					}

					case MODIFICA: {
						malattie = md.findAll();
						System.out.println("Inserisci l'id della malattia da modificare: ");
						int id = in.nextInt();
						Malattia m = ms.modificaMalattia(in, id);
						malattie.set(id - 1, m);
						break;
					}

					case ELIMINA: {
						System.out.println("Inserisci l'id della malattia da eliminare: ");
						int id = in.nextInt();
						ms.remove(id, malattie);
						break;
					}

					case CERCA: {
						System.out.println("Inserisci l'id della malattia da cercare: ");
						int id = in.nextInt();
						Malattia m = ms.findDiseaseById(id);
						System.out.println(m);
						break;
					}

					default: {
						System.out.println("Scelta non valida ");
						break;
					}
					}
				}

				while (scelta != ESCI);
			}

			else {

				if (s.equals("vaccini")) {

					do {
						scelta = getChoice();

						VaccinoService vs = new VaccinoService();
						VaccinoDao dao = new VaccinoDao();

						switch (scelta) {
						case STAMPALISTA: {
							ConcreteIterator ci = new ConcreteIterator();
							vaccini = dao.findAll();

							for (int i = -1; i < vaccini.size() - 1; i++) {
								if (hasNext(vaccini)) {
									MainApp2 mn = new MainApp2();
									System.out.println(mn.next(vaccini));
								} else {
									System.out.println("Lista terminata");
								}
							}

							break;
						}

						case AGGIUNGI: {
							vs.add(vaccini);
							break;
						}

						case MODIFICA: {
							vaccini = dao.findAll();
							System.out.println("Inserisci l'id del vaccino da modificare: ");
							int id = in.nextInt();
							Vaccino v = vs.modificaVaccino(in, id);
							vaccini.set(id - 1, v);
							break;
						}

						case ELIMINA: {
							System.out.println("Inserisci l'id del vaccino da eliminare: ");
							int id = in.nextInt();
							vs.remove(id, vaccini);
							break;
						}

						case CERCA: {
							System.out.println("Inserisci l'id del vaccino da cercare: ");
							int id = in.nextInt();
							Vaccino v = vs.findVaccineById(id);
							System.out.println(v);
							break;
						}

						default: {
							System.out.println("Scelta non valida ");
							break;
						}
						}
					}

					while (scelta != ESCI);
				}

				else {

					if (s.equals("vaccinazioni")) {

						do {

							scelta = getChoice();
							VaccinazioneService vs = new VaccinazioneService();
							VaccinazioneDao vd = new VaccinazioneDao();

							switch (scelta) {
							case STAMPALISTA: {
								vaccinazioni = vd.findAll();

								for (int i = -1; i < vaccinazioni.size() - 1; i++) {
									if (hasNext(vaccinazioni)) {
										MainApp2 mn = new MainApp2();
										System.out.println(mn.next(vaccinazioni));
									}

									else {
										System.out.println("Lista terminata");
									}
								}

								break;
							}

							case AGGIUNGI: {
								vs.add(vaccinazioni);
								break;
							}

							case MODIFICA: {
								vaccinazioni = vd.findAll();
								System.out.println("Inserisci l'id della vaccinazione da modificare: ");
								int id = in.nextInt();
								Vaccinazione v = vs.modificaVaccinazione(in, id);
								vaccinazioni.set(id - 1, v);
								break;
							}

							case ELIMINA: {
								System.out.println("Inserisci l'id della vaccinazione da eliminare: ");
								int id = in.nextInt();
								vs.remove(id, vaccinazioni);
								break;
							}

							case CERCA: {
								System.out.println("Inserisci l'id della vaccinazione da cercare: ");
								int id = in.nextInt();
								Vaccinazione v = vs.findVaccinationById(id);
								System.out.println(v);
								break;
							}

							default: {
								System.out.println("Scelta non valida ");
								break;
							}
							}
						}

						while (scelta != ESCI);
					}

					else {
						System.out.println("Errore nell'inserimento ");
					}
				}
			}
		}
	}
	
	
	public Object next(List<?> list)
	{
		position++;
		Object o = list.get(position);
		return o != null ? o : null;
	}

	@Override
	public boolean hasNext() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Persona next() {
		position++;
		Persona p = persone.get(position);
		return p != null ? p : null;

	}

	public static void printMenu() {
		System.out.println("1) Stampa lista\n2) Aggiungi\n3) Modifica\n4) Elimina\n5) Cerca\n0) Esci");
	}

	@Override
	public void add(List list) throws ParseException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void remove(int id, List list) {
		// TODO Auto-generated method stub
		
	}
}