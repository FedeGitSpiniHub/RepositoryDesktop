package it.jac.javadb.lezione1b.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.NativeQuery;

import it.jac.javadb.lezione1b.entity.Vaccinazione;
import it.jac.javadb.lezione1b.util.HibernateUtil;

public class VaccinazioneDao extends BaseDao {

	private static final Logger log = LogManager.getLogger(VaccinazioneDao.class);

	public void createVaccinazione(Vaccinazione vaccinazione) throws ParseException {
		
		StringBuilder sql = new StringBuilder();
		
		sql.append("INSERT INTO VACCINAZIONE (ID, DATA, CREATION_TIME, CREATION_USER)");
		sql.append(" VALUES (?, ?, ?, ?)");
		
		Connection connection = null;
		PreparedStatement pstm = null;
		
		try {
			connection = getConnection();
			
			pstm = connection.prepareStatement(sql.toString());
			
			pstm.setInt(1, vaccinazione.getId());
			pstm.setDate(2, vaccinazione.getData());
			pstm.setTimestamp(3, new java.sql.Timestamp(vaccinazione.getCreationTime().getTime()));
			pstm.setString(4, vaccinazione.getCreationUser());
			
			pstm.execute();
			
		} catch(SQLException | ClassNotFoundException e) {
			
			e.printStackTrace();
			
		} finally {
			
			if (pstm != null) {
				try {
					pstm.close();
				} catch (SQLException e) {
					
				}
			}
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {
					
				}
			}
		}
	}
	
	public Vaccinazione findVaccinationById(int id) {

		try (Session session = HibernateUtil.getSessionFactory().openSession()) {

			return session.find(Vaccinazione.class, id);
		}
	}
	
	public void save(Vaccinazione vaccinazione) {

		log.debug("try to save vaccination " + vaccinazione);
		
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {

			Transaction tx = session.beginTransaction();
			try {

				session.persist(vaccinazione);
				tx.commit();
				log.debug("Vaccination saved");
				
			} catch(Exception e) {
				log.error("Error saving vaccination", e);
				tx.rollback();
			}
		}
	}
	
	public void updateVaccinazione(Vaccinazione vaccination) throws ParseException {
		
		System.out.println("Stai modificando la vaccinazione n� " + vaccination.getId());
		
		StringBuilder sql = new StringBuilder();
		
		sql.append("UPDATE VACCINAZIONE");
		sql.append(" SET DATA = ?,");
		sql.append(" 	 UPDATE_TIME = ?,");
		sql.append(" 	 UPDATE_USER = ?");
		sql.append(" WHERE ID = ?");
				
		Connection connection = null;
		PreparedStatement pstm = null;
		
		try {
			connection = getConnection();
			
			pstm = connection.prepareStatement(sql.toString());
			
			
			pstm.setDate(1, vaccination.getData());
			pstm.setTimestamp(2, new java.sql.Timestamp(vaccination.getUpdateTime().getTime()));
			pstm.setString(3, vaccination.getUpdateUser());
			pstm.setInt(4, vaccination.getId());
			
			pstm.execute();
			
		} catch(SQLException | ClassNotFoundException e) {
			
			e.printStackTrace();
			
		} finally {
			
			if (pstm != null) {
				try {
					pstm.close();
				} catch (SQLException e) {
					
				}
			}
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {
					
				}
			}
		}
	}
	
	public void deleteVaccination(int id) {
		
		StringBuilder sql = new StringBuilder();
		
		sql.append("DELETE FROM VACCINAZIONE");
		sql.append(" WHERE ID = ?");
				
		Connection connection = null;
		PreparedStatement pstm = null;
		
		try {
			connection = getConnection();
			
			pstm = connection.prepareStatement(sql.toString());
			
			pstm.setInt(1, id);
			
			pstm.execute();
			
		} catch(SQLException | ClassNotFoundException e) {
			
			e.printStackTrace();
			
		} finally {
			
			if (pstm != null) {
				try {
					pstm.close();
				} catch (SQLException e) {
					
				}
			}
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {
					
				}
			}
		}
	}
	
	public List<Vaccinazione> findAll() {

		log.debug("try to find all entities");
		
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			
			NativeQuery<Vaccinazione> query = session.createNativeQuery("select * from vaccinazione", Vaccinazione.class);
	
			List<Vaccinazione> list = query.list();
			
			log.debug("found [" + list.size() + "] entities");
			
			return list;
		}
	}
}
