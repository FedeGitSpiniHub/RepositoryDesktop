package it.jac.javadb.lezione1b.entity;

import java.io.Serializable;
import java.text.ParseException;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

//import org.hibernate.mapping.Set;
import java.util.Set;

@Entity
@Table(name = "persona")
public class Persona implements Serializable {
	
	@ManyToMany(cascade = { CascadeType.ALL })
	    @JoinTable(
	        name = "vaccinato", 
	        joinColumns = { @JoinColumn(name = "idpersona", referencedColumnName = "id") }, 
	        inverseJoinColumns = { @JoinColumn(name = "idvaccinazione", referencedColumnName = "id") }
	    )
	private Set<Vaccinazione> vaccinazioni = new HashSet<Vaccinazione>();
	
	@ManyToMany(cascade = { CascadeType.ALL })
    @JoinTable(
        name = "somministrazione", 
        joinColumns = { @JoinColumn(name = "idpersona", referencedColumnName = "id") }, 
        inverseJoinColumns = { @JoinColumn(name = "idvaccinazione", referencedColumnName = "id") }
    )
	private Set<Vaccinazione> vaccinations = new HashSet<Vaccinazione>();
	
	@ManyToMany(cascade = { CascadeType.ALL })
    @JoinTable(
        name = "somministrazione", 
        joinColumns = { @JoinColumn(name = "idpersona", referencedColumnName = "id") }, 
        inverseJoinColumns = { @JoinColumn(name = "idvaccino", referencedColumnName = "id") }
    )
	private Set<Vaccino> vaccines = new HashSet<Vaccino>();
	 
	 @ManyToMany(cascade=CascadeType.ALL, fetch = FetchType.LAZY)
	    @JoinTable(
	        name = "ammalato",
	        joinColumns = { @JoinColumn(name = "idpersona", referencedColumnName="id") }, 
	        inverseJoinColumns = { @JoinColumn(name = "idmalattia", referencedColumnName="id") }
	    )
	 	private Set<Malattia> malattie = new HashSet<Malattia>();

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;
	
	@Column(name = "nome", length = 30)
	private String nome;
	
	@Column(name = "cognome", length = 30)
	private String cognome;
	
	@Column(name = "data_nascita")
	private java.sql.Date dataNascita;
	
	@Column(name = "recapito_telefonico", length = 20)
	private String recapitoTelefonico;
	
	@Column(name = "indirizzo_residenza", length = 40)
	private String indirizzoResidenza;
	
	@Column(name = "creation_user", length = 20)
	private String creationUser;
	
	@Column(name = "update_user", length = 20)
	private String updateUser;
	
	@Column(name = "creation_time")
	private Date creationTime;
	
	@Column(name = "update_time")
	private Date updateTime;
	
	public static Iterator iterator() {
		
		Iterator<Persona> persone = Persona.iterator();
		return persone;
    }
    
    public Persona()
    {
    	
    }
    
    public Persona(int id, String nome, String cognome, String dataNascita, String recapitoTelefonico, String indirizzoResidenza) throws ParseException
    {
    	this.setId(id);
    	this.setNome(nome);
    	this.setCognome(cognome);
    	this.setDataNascita(dataNascita);
    	this.setRecapitoTelefonico(recapitoTelefonico);
    	this.setIndirizzoResidenza(indirizzoResidenza);
    }
	public String getCognome() {
		return cognome;
	}

	public void setCognome(String cognome) {
		this.cognome = cognome;
	}

	public String getRecapitoTelefonico() {
		return recapitoTelefonico;
	}

	public void setRecapitoTelefonico(String recapitoTelefonico) {
		this.recapitoTelefonico = recapitoTelefonico;
	}

	public String getIndirizzoResidenza() {
		return indirizzoResidenza;
	}

	public void setIndirizzoResidenza(String indirizzoResidenza) {
		this.indirizzoResidenza = indirizzoResidenza;
	}

	public java.sql.Date getDataNascita() {
		return dataNascita;
	}

	public void setDataNascita(String dataNascita) throws ParseException {
		this.dataNascita = java.sql.Date.valueOf(dataNascita);
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((nome == null) ? 0 : nome.hashCode());
		result = prime * result + ((creationTime == null) ? 0 : creationTime.hashCode());
		result = prime * result + ((creationUser == null) ? 0 : creationUser.hashCode());
		result = prime * result + ((cognome == null) ? 0 : cognome.hashCode());
		result = prime * result + id;
		result = prime * result + ((indirizzoResidenza == null) ? 0 : indirizzoResidenza.hashCode());
		result = prime * result + ((recapitoTelefonico == null) ? 0 : recapitoTelefonico.hashCode());
		result = prime * result + ((updateTime == null) ? 0 : updateTime.hashCode());
		result = prime * result + ((updateUser == null) ? 0 : updateUser.hashCode());
		result = prime * result + ((dataNascita == null) ? 0 : dataNascita.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Persona other = (Persona) obj;
		if (nome == null) {
			if (other.nome != null)
				return false;
		} else if (!nome.equals(other.nome))
			return false;
		if (creationTime == null) {
			if (other.creationTime != null)
				return false;
		} else if (!creationTime.equals(other.creationTime))
			return false;
		if (creationUser == null) {
			if (other.creationUser != null)
				return false;
		} else if (!creationUser.equals(other.creationUser))
			return false;
		if (cognome == null) {
			if (other.cognome != null)
				return false;
		} else if (!cognome.equals(other.cognome))
			return false;
		if (id != other.id)
			return false;
		if (indirizzoResidenza == null) {
			if (other.indirizzoResidenza != null)
				return false;
		} else if (!recapitoTelefonico.equals(other.recapitoTelefonico))
			return false;
		if (dataNascita == null) {
			if (other.dataNascita != null)
				return false;
		} else if (!dataNascita.equals(other.dataNascita))
			return false;
		if (updateTime == null) {
			if (other.updateTime != null)
				return false;
		} else if (!updateTime.equals(other.updateTime))
			return false;
		if (updateUser == null) {
			if (other.updateUser != null)
				return false;
		} else if (!updateUser.equals(other.updateUser))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "id: " + id + ", nome: " + nome + ", cognome: " + cognome + ", recapito telefonico: "
				+ recapitoTelefonico + ", indirizzo di residenza: " + indirizzoResidenza + ", data di nascita: " + dataNascita
				+ ", creation time: " + creationTime + ", creation user: " + creationUser + ", update time: " + updateTime 
				+ ", update user: " + updateUser + " ";
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Date getCreationTime() {
		return creationTime;
	}

	public void setCreationTime(Date creationTime) {
		this.creationTime = creationTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public String getCreationUser() {
		return creationUser;
	}

	public void setCreationUser(String creationUser) {
		this.creationUser = creationUser;
	}

	public String getUpdateUser() {
		return updateUser;
	}

	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}
}
