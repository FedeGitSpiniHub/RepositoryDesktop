package it.jac.javadb.lezione1b.service;

import java.util.Iterator;

public interface Aggregator {
	
	public Iterator createIterator();
}
