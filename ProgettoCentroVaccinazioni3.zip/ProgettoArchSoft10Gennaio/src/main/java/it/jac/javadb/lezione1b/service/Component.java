package it.jac.javadb.lezione1b.service;

import java.util.List;
import java.text.ParseException;

public interface Component<T> {
	
	public void add(List<T> list) throws ParseException;
	public void remove(int id, List<T> list);
	public void operation() throws ParseException;

}
