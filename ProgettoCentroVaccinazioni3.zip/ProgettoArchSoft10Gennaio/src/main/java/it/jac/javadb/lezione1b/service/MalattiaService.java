package it.jac.javadb.lezione1b.service;

import java.text.ParseException;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import it.jac.javadb.lezione1b.dao.AmmalatoDao;
import it.jac.javadb.lezione1b.dao.MalattiaDao;
import it.jac.javadb.lezione1b.dao.PersonaDao;
import it.jac.javadb.lezione1b.entity.Ammalato;
import it.jac.javadb.lezione1b.entity.Malattia;
import it.jac.javadb.lezione1b.entity.Persona;
import it.jac.javadb.lezione1b.util.Utils;

public class MalattiaService implements Component<Malattia> {
	
	private static MalattiaDao dao = new MalattiaDao();
	
	@Override
	public void add(List<Malattia> malattie) throws ParseException {
		Scanner scanner = new Scanner(System.in);
		MalattiaService ms = new MalattiaService();
		Malattia malattia = ms.creaMalattia(scanner);
		malattie.add(malattia);
	}
	
	@Override
	public void remove(int idMalattia, List<Malattia> malattie) {
		Scanner scanner = new Scanner(System.in);
		MalattiaService ms = new MalattiaService();
		ms.eliminaMalattia(idMalattia);
		Malattia m = ms.findDiseaseById(idMalattia);
	
		for(Malattia malattia: malattie)
		{
			if(malattia.equals(m))
			{
				malattie.remove(malattia);
			}
		}
	}
	
	public void eliminaMalattia(int idMalattia) {

		System.out.println("Elimina malattia n� " + idMalattia);

		dao.deleteMalattia(idMalattia);
	}
	
	public Malattia modificaMalattia(Scanner s, int id) throws ParseException
	{
		String tipo, nome;
		
		System.out.println("Modifica malattia n� " + id);
		
		System.out.println("Inserisci tipo: ");
		tipo = s.next();
		
		System.out.println("Inserisci nome: ");
		nome = s.next();
		
		Malattia malattia = new Malattia();
		malattia.setTipo(tipo);
		malattia.setNome(nome);
		malattia.setId(id);
		malattia.setUpdateTime(new Date());
		malattia.setUpdateUser("admin");
	
		dao.updateMalattia(malattia);
		
		return malattia;
	}
	
	public Malattia creaMalattia(Scanner s) throws ParseException {
		
		String tipo, nome;
		
		System.out.println("Crea malattia");

		System.out.println("Inserisci il tipo:");
		tipo = s.nextLine();
		
		System.out.println("Inserisci il nome:");
		nome = s.nextLine();
		
		Malattia malattia = new Malattia();
		malattia.setTipo(tipo);
		malattia.setNome(nome);
		malattia.setId(7);
		malattia.setCreationTime(new Date());
		malattia.setCreationUser("admin");
		
		dao.createMalattia(malattia);
		
		return malattia;
	}
	
	public void getPersoneAmmalate()
	{
		PersonaDao pd = new PersonaDao();
		List<Persona> persone = pd.findAll();
		AmmalatoDao ad = new AmmalatoDao();
		List<Ammalato> ammalati = ad.findAll();
		MalattiaService ms = new MalattiaService();
		
		for(int i = 0; i < persone.size(); i++)
		{
			for(int j = 0; j < ammalati.size(); j++)
			{
				if(persone.get(i).getId() == ammalati.get(j).getIdpersona())
				{
					Malattia m = ms.findDiseaseById(ammalati.get(j).getIdmalattia());
					System.out.println("La seguente malattia: " + m.getNome() + " � stata contratta dalle persone: " + ammalati.get(j).getIdpersona());
				}
			}
		}
	}
	
	public Malattia findDiseaseById(int id) {
		return dao.findDiseaseById(id);
	}
	
	public void stampaMalattia(int idMalattia) {

		System.out.println("Stampa malattia ");

		Malattia malattia = dao.findDiseaseById(idMalattia);
		
		Utils u = new Utils();
		
		u.stampaListaMalattie(Arrays.asList(malattia));
	}

	@Override
	public void operation() {
	}
}
